// DNS Client
import java.net.*;

public class DNSClient {
    public static void main(String[] args) {
        DatagramSocket socket = null;

        try {
            socket = new DatagramSocket();
            InetAddress serverAddress = InetAddress.getByName("localhost"); // Server address

            // DNS query for "example.com"
            String query = "example.com";
            byte[] queryData = query.getBytes();

            DatagramPacket queryPacket = new DatagramPacket(queryData, queryData.length, serverAddress, 9876);

            socket.send(queryPacket); // Send DNS query

            // Receive DNS response
            byte[] responseData = new byte[1024];
            DatagramPacket responsePacket = new DatagramPacket(responseData, responseData.length);

            socket.receive(responsePacket); // Receive DNS response

            String ipAddress = new String(responsePacket.getData(), 0, responsePacket.getLength());
            System.out.println("Resolved IP address: " + ipAddress);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }
    }
}
