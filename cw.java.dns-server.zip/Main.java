// DNS Server
import java.net.*;
import java.util.Arrays;

public class DNSServer {
    public static void main(String[] args) {
        DatagramSocket socket = null;
        
        try {
            socket = new DatagramSocket(9876); // UDP socket on port 9876
            
            while (true) {
                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                
                socket.receive(receivePacket); // Receive DNS query
                
                String domain = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Received DNS query for domain: " + domain);
                
                // Simulated DNS resolution (for example, resolving "example.com" to "192.168.1.1")
                String ipAddress = "192.168.1.1";
                
                // Send DNS response
                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();
                byte[] responseData = ipAddress.getBytes();
                DatagramPacket responsePacket = new DatagramPacket(responseData, responseData.length, clientAddress, clientPort);
                
                socket.send(responsePacket);
                System.out.println("Sent DNS response with IP: " + ipAddress);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }
    }
}
